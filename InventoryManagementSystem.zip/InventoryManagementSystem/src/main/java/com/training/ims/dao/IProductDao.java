package com.training.ims.dao;

import java.util.List;
import javax.sql.DataSource;
import com.training.ims.model.ProductModel;

public interface IProductDao {
	public abstract void setDataSource(DataSource dataSource);
	public abstract boolean addProduct(ProductModel productModel);
	public abstract List<ProductModel> getProductsList ();
	public abstract boolean deleteProduct(String productId);
	public abstract List<ProductModel> getProductDetailsToEdit(String productId);
	public abstract boolean editProduct(ProductModel productModel);
}
