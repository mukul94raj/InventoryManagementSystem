package com.training.ims.model;

public class UserModel {
	private String userId;
	private String userFirstName;
	private String userLastName;
	
	private String userPhoneNumber;
	
	private String userEmail;
	private String userRole;
	
	private String userAddress;
	private String userCity;
	private String userState;
	
	private int userPinCode;
	
	private String userPassword;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserPhoneNumber() {
		return userPhoneNumber;
	}

	public void setUserPhoneNumber(String userPhoneNumber) {
		this.userPhoneNumber = userPhoneNumber;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserCity() {
		return userCity;
	}

	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	public int getUserPinCode() {
		return userPinCode;
	}

	public void setUserPinCode(int userPinCode) {
		this.userPinCode = userPinCode;
	}
	
	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	

	@Override
	public String toString() {
		return "UserModel [userId=" + userId + ", userFirstName=" + userFirstName + ", userLastName=" + userLastName
				+ ", userPhoneNumber=" + userPhoneNumber + ", userEmail=" + userEmail + ", userAddress=" + userAddress
				+ ", userCity=" + userCity + ", userState=" + userState + ", userPinCode=" + userPinCode + "]";
	}



}
