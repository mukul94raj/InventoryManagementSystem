package com.training.ims.dao;

import java.util.List;

import javax.sql.DataSource;


import com.training.ims.model.UserModel;

public interface IUserDao {
	public abstract void setDataSource(DataSource dataSource);
	public abstract boolean addUserInfo(UserModel userModel);
	public abstract boolean deletingUser(String userId);
	public abstract List<UserModel> getUsers();
	public abstract List<UserModel> getUserDetailsToEdit (String userId);
	public abstract boolean editUser(UserModel userModel);
}
