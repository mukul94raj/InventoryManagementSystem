package com.training.ims.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.training.ims.model.ProductModel;
import com.training.ims.model.SupplierModel;
import com.training.ims.service.IProductService;
import com.training.ims.service.ISupplierService;

@Controller
public class ProductController {
	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private ISupplierService supplierService;
	
	static Logger logger = Logger.getLogger(LoginController.class);
	
	@RequestMapping(value="/addProduct",method = RequestMethod.GET)
	public ModelAndView AddProcess(HttpServletRequest request,HttpServletResponse response,ProductModel productModel){
    	
		logger.info("A Form is displayed to add product");		
		
		List<SupplierModel> SupplierList = supplierService.getSuppliers();
		List<String> SupplierNamelist = new ArrayList<String>();
		for(int i=0; i<SupplierList.size();i++){
			SupplierNamelist.add(SupplierList.get(i).getSupplierFirstName());
		}
		
		List<ProductModel> Productlist = productService.getProductsList();
		List<String> ProductIdList = new ArrayList<String>();
		for(int i=0; i<Productlist.size();i++){
			ProductIdList.add(Productlist.get(i).getProductId());
		}
		
		String attach = "addproduct" ;
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);    	
    	model.addObject("supplierNames", SupplierNamelist);
    	model.addObject("ListOfIds",ProductIdList);
    	return model;
    }	
	
	@RequestMapping(value="/addProd",method = RequestMethod.POST)
	public ModelAndView Addition(@ModelAttribute("productModel") @Valid ProductModel productModel,BindingResult result) {
		
		boolean addedStatus = productService.addProduct(productModel);

		ModelAndView view = new ModelAndView("successview");
		String attach = "Message" ;
		view.addObject("attachModel",attach);
		List<ProductModel> productList = productService.getProductsList();
		view.addObject("reattachModel","viewproducts");
		view.addObject("listofproducts", productList);
		
		if(addedStatus){
			view.addObject("message","Product added successfully");
			logger.info("Product added Successfully");
		}
		else
		{
			view.addObject("message","Sorry! Product not added");
			logger.warn("Product could not be added");
		}
		return view;
	}
	
	@RequestMapping(value="/viewProduct",method = RequestMethod.GET)
	public ModelAndView ViewProcess(){
    	
		logger.info("Product data is being viewed");
		
		List<ProductModel> productList = productService.getProductsList();
		
		String attach = "viewproducts" ;
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);  
    	model.addObject("listofproducts", productList); 
    	return model;
    }	
	
	@RequestMapping(value = "/deleteProd", method = RequestMethod.POST)
	public ModelAndView delete(@RequestParam("prodId") String productId ){
		
		boolean isdeleted = productService.deleteProduct(productId);
		
		ModelAndView view = new ModelAndView("successview");
		String attach = "Message" ;
		view.addObject("attachModel",attach);
		List<ProductModel> productList = productService.getProductsList();
		view.addObject("reattachModel","viewproducts"); 
		view.addObject("listofproducts", productList);
		
		if(isdeleted){
			view.addObject("message","Product data deleted successfully");   
			logger.info("Product data deleted successfully");
		}
		else{
			view.addObject("message", "Sorry! Product data cannot be deleted");
			logger.info("Product data could not be deleted");
		}
		
		return view;
	}
	
	@RequestMapping(value = "/editProductDetails", method = RequestMethod.POST)
	 public ModelAndView editingDetails(ProductModel productModel,BindingResult result,@RequestParam("prodId") String productId ){
	  
	  logger.info("Data of the product with Id "+ productId +" to be edited");
	  
	  List<ProductModel> productList = productService.getProductDetailsToEdit(productId);
	  
	  String attach = "productInfoToEdit" ;
	     ModelAndView model=new ModelAndView("successview");
	     model.addObject("attachModel",attach);   
	     model.addObject("listofproducts",productList);     
	     return model;
	 }
	 
	 @RequestMapping(value = "/editProduct", method = RequestMethod.POST)
	 public ModelAndView edit(@ModelAttribute("productModel") @Valid ProductModel productModel,BindingResult result){
	  
	  boolean isedited = false;
	  
	  try{
	   isedited = productService.editProduct(productModel);
	  }
	  catch (NullPointerException e) {
	   // TODO: handle exception
	   logger.error("An error has occurred while editing product data in database");
	  }
		ModelAndView view = new ModelAndView("successview");
		String attach = "Message" ;
		view.addObject("attachModel",attach);
		List<ProductModel> productList = productService.getProductsList();
		view.addObject("reattachModel","viewproducts");  
		view.addObject("listofproducts", productList);
	  
	  if(isedited){
		  view.addObject("message","Product data edited successfully"); 
		  logger.info("Product data edited successfully");
	  }
	  else{
		  view.addObject("message", "Sorry! Product Data cannot be edited");  
		  logger.warn("Product data could not be edited");
	  }  
	  return view;
	 }
	
	
}

