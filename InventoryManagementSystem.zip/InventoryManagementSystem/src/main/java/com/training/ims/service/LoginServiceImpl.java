package com.training.ims.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.ims.dao.ILoginDao;
import com.training.ims.model.LoginModel;

public class LoginServiceImpl implements ILoginService{
	
	@Autowired
	private ILoginDao loginDao;

	public boolean authenticateUser(LoginModel loginModel) throws SQLException {
		// TODO Auto-generated method stub
		return loginDao.authenticateUser(loginModel);
	}

	public String setRoleOfUser(LoginModel loginModel) {
		// TODO Auto-generated method stub
		return loginDao.setRoleOfUser(loginModel);
	}

	public String setUserName(LoginModel loginModel) {
		// TODO Auto-generated method stub
		return loginDao.setUserName(loginModel);
	}

}
