
package com.training.ims.dao;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import com.training.ims.model.UserModel;

@SuppressWarnings("deprecation")
public class UserDaoImpl implements IUserDao{

	private SimpleJdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		// TODO Auto-generated method stub
		this.jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	public boolean addUserInfo(UserModel userModel) {
		// TODO Auto-generated method stub
		String insertQuery = "insert into user_table values(:custId, :fnmae, :lname, :phno, :email, :addr, :city, :state, :pincode, :role)";
		  
		Map<String, Object> parameters = new HashMap<String, Object>();
			
	    parameters.put("custId", userModel.getUserId());
		parameters.put("fnmae", userModel.getUserFirstName());
		parameters.put("lname", userModel.getUserLastName());
		parameters.put("phno", userModel.getUserPhoneNumber());
		parameters.put("email", userModel.getUserEmail());
		parameters.put("addr", userModel.getUserAddress());
		parameters.put("city", userModel.getUserCity());
		parameters.put("state", userModel.getUserState());
		parameters.put("pincode", userModel.getUserPinCode());	
		parameters.put("role", userModel.getUserRole());	
		
		int rowcount = jdbcTemplate.update(insertQuery, parameters);
		
		if(rowcount == 1){
			Map<String, Object> logTableParameter = new HashMap<String, Object>();
			String insertLogQuery = "insert into LOGIN_TABLE values(:id,:uname,:pass,:role)";
			logTableParameter.put("id", userModel.getUserId());
			logTableParameter.put("uname", userModel.getUserFirstName());
			logTableParameter.put("pass", userModel.getUserPassword());
			logTableParameter.put("role", userModel.getUserRole());	
			
			int logcount = jdbcTemplate.update(insertLogQuery, logTableParameter);
			if(logcount == 1){
				return true;
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}

	public boolean deletingUser(String userId) {
		// TODO Auto-generated method stub
		String query = "Delete from user_table where USER_ID = '"+userId+"'";
		System.out.println("delete query: "+ query);
		int rowCount = jdbcTemplate.update(query);
		if(rowCount >0){
			return true;
		}
		else{
			return false;
		}	
	}

	public List<UserModel> getUsers() {
		  // TODO Auto-generated method stub
		  String query = "select USER_ID,FIRST_NAME,LAST_NAME,PHONE_NUMBER,EMAIL,ADDRESS,CITY,STATE,PINCODE from user_table";
		  List<UserModel> userInfoList = jdbcTemplate.query(query, new RowMapper<UserModel>(){

			public UserModel mapRow(ResultSet result, int rowNum) throws SQLException {
				UserModel user = new UserModel();
				user.setUserId(result.getString("USER_ID"));
				user.setUserFirstName(result.getString("FIRST_NAME"));
				user.setUserLastName(result.getString("LAST_NAME"));
				user.setUserPhoneNumber(result.getString("PHONE_NUMBER"));
				user.setUserEmail(result.getString("EMAIL"));
				user.setUserAddress(result.getString("ADDRESS"));
				user.setUserCity(result.getString("CITY"));
				user.setUserState(result.getString("STATE"));
				user.setUserPinCode(result.getInt("PINCODE"));
				
				return user;
			}
			
		});
		return userInfoList;
	}

	public List<UserModel> getUserDetailsToEdit(String userId) {
		// TODO Auto-generated method stub
		 String query = "select * from user_table where USER_ID = '"+userId+"'";
		  System.out.println("query to fetch details: "+query); 
		  List<UserModel> userInfoList = jdbcTemplate.query(query, new RowMapper<UserModel>(){

		   public UserModel mapRow(ResultSet result, int rowNum) throws SQLException {
		    UserModel user = new UserModel();
		    user.setUserId(result.getString("USER_ID"));
		    user.setUserFirstName(result.getString("FIRST_NAME"));
		    user.setUserLastName(result.getString("LAST_NAME"));
		    user.setUserPhoneNumber(result.getString("PHONE_NUMBER"));
		    user.setUserEmail(result.getString("EMAIL"));
		    user.setUserAddress(result.getString("ADDRESS"));
		    user.setUserCity(result.getString("CITY"));
		    user.setUserState(result.getString("STATE"));
		    user.setUserPinCode(result.getInt("PINCODE"));
		    System.out.println(user);
		    return user;
		   }
		  });
		  return userInfoList;
	}

	public boolean editUser(UserModel userModel) {
		// TODO Auto-generated method stub
		String editQuery = "update user_table set FIRST_NAME = :fname, LAST_NAME = :lname, PHONE_NUMBER = :phno, EMAIL = :email, ADDRESS = :addr, CITY = :city, STATE = :state, PINCODE = :pincode "
			    + " WHERE USER_ID = :userId ";
			    
		   Map<String, Object> parameters = new HashMap<String, Object>();
		   
		   parameters.put("userId", userModel.getUserId());
		   parameters.put("fname", userModel.getUserFirstName());
		   parameters.put("lname", userModel.getUserLastName());
		   parameters.put("phno", userModel.getUserPhoneNumber());
		   parameters.put("email", userModel.getUserEmail());
		   parameters.put("addr", userModel.getUserAddress());
		   parameters.put("city", userModel.getUserCity());
		   parameters.put("state", userModel.getUserState());
		   parameters.put("pincode", userModel.getUserPinCode());
		   
		   int rowcount = jdbcTemplate.update(editQuery, parameters);
		   
		   if(rowcount == 1){
		    return true;   
		   }
		   else{
		    return false;
		   }
	}
}
