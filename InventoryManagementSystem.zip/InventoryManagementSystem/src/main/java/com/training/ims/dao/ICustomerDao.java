package com.training.ims.dao;

import java.util.List;

import javax.sql.DataSource;

import com.training.ims.model.CustomerModel;

public interface ICustomerDao {
	public abstract void setDataSource(DataSource dataSource);
	public abstract boolean addCustomer(CustomerModel customerModel);
	public abstract List<CustomerModel> getCustomers();
	public abstract boolean deleteCustomer(String customerId);
	public abstract List<CustomerModel> getCustomerDetailsToEdit (String custId);
	public abstract boolean editCustomer(CustomerModel customerModel);
}
