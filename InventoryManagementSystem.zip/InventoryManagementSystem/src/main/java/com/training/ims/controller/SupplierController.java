package com.training.ims.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.training.ims.model.SupplierModel;

import com.training.ims.service.ISupplierService;


@Controller
public class SupplierController {

	@Autowired
	private ISupplierService supplierService;
	
	static Logger logger = Logger.getLogger(SupplierController.class);
	
	@RequestMapping(value="/addSupplier",method = RequestMethod.GET)
	public ModelAndView Adding(HttpServletRequest request,HttpServletResponse response,SupplierModel supplierModel){
    	
		logger.info("A Form to add a supplier is being loaded");
		
		List<SupplierModel> supplierList = supplierService.getSuppliers();
		List<String> supplierIdList = new ArrayList<String>();
		for(int i = 0; i<supplierList.size();i++){
			supplierIdList.add(supplierList.get(i).getSupplierId());
		}
		
		String attach = "addsupplier" ;
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);    
    	model.addObject("ListOfIds",supplierIdList);
    	return model;
    }
	
	
	@RequestMapping(value="/addSup",method = RequestMethod.POST)
	public ModelAndView Addition(@ModelAttribute("supplierModel") @Valid SupplierModel supplierModel,BindingResult result) {

		boolean addedStatus = supplierService.addSupplier(supplierModel);
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach);   
    	List<SupplierModel> supplierList = supplierService.getSuppliers();
    	viewModel.addObject("reattachModel", "viewsupplier");
    	viewModel.addObject("supplierinfo",supplierList);   
    					
		if(addedStatus){
			viewModel.addObject("message", "Supplier Data Successfully Added");
			logger.info("Supplier Data Successfully Added");
		}
		else
		{
			viewModel.addObject("message", "Sorry! Supplier data could not be added");
			logger.warn("Supplier data could not be added");
		}
		return viewModel;
	}
	
	
	@RequestMapping(value = "/deletesup", method = RequestMethod.POST)
	public ModelAndView delete(@RequestParam("suppId") String suppId ){
		
		boolean isdeleted = supplierService.deleteSupplier(suppId);
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach);   
    	List<SupplierModel> supplierList = supplierService.getSuppliers();
    	viewModel.addObject("reattachModel", "viewsupplier");
    	viewModel.addObject("supplierinfo",supplierList); 
    	
		if(isdeleted){
			viewModel.addObject("message","Supplier data deleted successfully");    
			logger.info("Supplier data deleted successfully");
		}
		else{
			viewModel.addObject("message", "Sorry! Supplier Data cannot be deleted");  
			logger.warn("Supplier data could not be deleted");
		}
		
		return viewModel;
	}
	
	
	
	@RequestMapping(value = "/viewSupplier", method = RequestMethod.GET)
	public ModelAndView getSuppliers(){
		
		 logger.info("Supplier data is being viewed");
		
		List<SupplierModel> supplierList = supplierService.getSuppliers();
		
		String attach = "viewsupplier";
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);   
    	model.addObject("supplierinfo",supplierList);    	
    	return model;
    	
	}
	
	@RequestMapping(value = "/editSupplierDetails", method = RequestMethod.POST)
	public ModelAndView editSupplierDetails(SupplierModel supplierModel,BindingResult result,@RequestParam("suppId") String supplierId ){
		
		logger.info("Data of the supplier with Id "+ supplierId +" to be edited");
		
		List<SupplierModel> supplierList = supplierService.getSupplierDetailsToEdit(supplierId);
		
		String attach = "supplierInfoToEdit" ;
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);   
    	model.addObject("supplierinfo",supplierList);    	
    	return model;
	}
	
	@RequestMapping(value = "/editSupp", method = RequestMethod.POST)
	public ModelAndView editSupplier(@ModelAttribute("supplierModel") @Valid SupplierModel supplierModel,BindingResult result){
		
		boolean isedited = false;
		
		try{
			isedited = supplierService.editSupplier(supplierModel);
		}
		catch (NullPointerException e) {
			// TODO: handle exception
			logger.error("An error has occurred while editing customer data from datbase");
		}
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach); 
    	List<SupplierModel> supplierList = supplierService.getSuppliers();
    	viewModel.addObject("reattachModel", "viewsupplier");
    	viewModel.addObject("supplierinfo",supplierList); 
    			
		if(isedited){
			viewModel.addObject("message","Supplier Data edited successfully");    
			logger.info("Supplier Data edited successfully");
		}
		else{
			viewModel.addObject("message", "Sorry! Supplier Data cannot be deleted");  
			logger.warn("Supplier data cannot be deleted");
		}		
		return viewModel;
	}
	
}


	
	
	
	

