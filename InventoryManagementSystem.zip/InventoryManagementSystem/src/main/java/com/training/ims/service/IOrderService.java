package com.training.ims.service;

import java.util.List;

import com.training.ims.model.Order;

public interface IOrderService {
	
	public abstract boolean addOrder(Order order);
	public abstract List<Order> getOrders();
	public abstract List<Order> getOrderDetailsToEdit(String orderId);
	public abstract boolean editOrder(Order order,int editQuant);
	public abstract boolean deleteOrder(String orderId);
}
