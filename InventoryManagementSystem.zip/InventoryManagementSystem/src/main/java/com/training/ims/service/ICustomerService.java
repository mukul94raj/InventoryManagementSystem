package com.training.ims.service;

import java.util.List;

import com.training.ims.model.CustomerModel;

public interface ICustomerService {
	public abstract boolean addCustomer(CustomerModel customerModel);
	public abstract boolean deleteCustomer(String customerId);
	public abstract List<CustomerModel> getCustomers();
	public abstract List<CustomerModel> getCustomerDetailsToEdit (String custId);
	public abstract boolean editCustomer(CustomerModel customerModel);
}
