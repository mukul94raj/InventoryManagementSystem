package com.training.ims.service;

import java.util.List;


import com.training.ims.model.SupplierModel;

public interface ISupplierService {
	public abstract boolean addSupplier(SupplierModel supplierModel);
	public abstract boolean deleteSupplier(String suppId);
	public abstract List<SupplierModel> getSuppliers();
	public abstract List<SupplierModel> getSupplierDetailsToEdit (String custId);
	public abstract boolean editSupplier(SupplierModel supplierModel);
}
