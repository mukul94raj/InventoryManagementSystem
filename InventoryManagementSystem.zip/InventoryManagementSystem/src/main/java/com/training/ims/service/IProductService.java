package com.training.ims.service;

import java.util.List;

import com.training.ims.model.ProductModel;

public interface IProductService {
	 public abstract boolean addProduct(ProductModel productModel);
	 public abstract List<ProductModel> getProductsList ();
	 public abstract boolean deleteProduct(String productId);
	 public abstract List<ProductModel> getProductDetailsToEdit (String productId);
	 public abstract boolean editProduct(ProductModel productModel);
}
