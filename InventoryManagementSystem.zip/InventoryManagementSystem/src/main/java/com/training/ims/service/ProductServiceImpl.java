package com.training.ims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.ims.dao.IProductDao;
import com.training.ims.model.ProductModel;

public class ProductServiceImpl implements IProductService{

	@Autowired
	private IProductDao productDao;
	
	public boolean addProduct(ProductModel productModel) {
		// TODO Auto-generated method stub
		return productDao.addProduct(productModel);
	}

	public List<ProductModel> getProductsList() {
		// TODO Auto-generated method stub
		return productDao.getProductsList();
	}

	public boolean deleteProduct(String productId) {
		// TODO Auto-generated method stub
		return productDao.deleteProduct(productId);
	}

	public List<ProductModel> getProductDetailsToEdit(String productId) {
		// TODO Auto-generated method stub
		return productDao.getProductDetailsToEdit(productId);
	}

	public boolean editProduct(ProductModel productModel) {
		// TODO Auto-generated method stub
		return productDao.editProduct(productModel);
	}

}
