package com.training.ims.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import com.training.ims.model.Order;

@SuppressWarnings("deprecation")
public class OrderDaoImpl implements IOrderDao {

	private SimpleJdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		// TODO Auto-generated method stub
		this.jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	public boolean addOrder(Order order) {
		
		String insertQuery = "insert into ORDER_DETAILS_TABLE values(:oid, :uid, :cid, :odate, :del, :pname, :sname, :quant ,:uprice, :tprice)";
		String editQuery = "update product set STOCK = STOCK - :quant where PRODUCT_NAME = :pname and SUPPLIER_NAME = :sname";
				
		   Map<String, Object> parameters = new HashMap<String, Object>();
		   
		   parameters.put("oid", order.getOrderId());
		   parameters.put("uid", order.getUserId());
		   parameters.put("cid", order.getCustomerId());
		   parameters.put("odate", order.getOrderDate());
		   parameters.put("del", order.getDeliveryDate());
		   parameters.put("pname", order.getProductName());
		   parameters.put("sname", order.getSupplierName());
		   parameters.put("quant", order.getQuantity());
		   parameters.put("uprice", order.getUnitPrice());
		   parameters.put("tprice", order.getTotalPrice());
		   
		   int rowcount = jdbcTemplate.update(insertQuery, parameters);
		   int stockUpdate = jdbcTemplate.update(editQuery, parameters);
		
		if(rowcount == 1){
			if(stockUpdate==1){
				return true;
			}
			else{
				//delete the order row
				return false;
			}
		}
		else{
			return false;
		}
	}

	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		String query = "select * from ORDER_DETAILS_TABLE";
		 
		  List<Order> orderInfoList = jdbcTemplate.query(query, new RowMapper<Order>(){

			   public Order mapRow(ResultSet result, int rowNum) throws SQLException {
				   Order order = new Order();
				   order.setOrderId(result.getString("ORDER_ID"));
				   order.setUserId(result.getString("USER_ID"));
				   order.setCustomerId(result.getString("CUSTOMER_ID"));
				   order.setOrderDate(result.getDate("ORDER_DATE"));
				   order.setDeliveryDate(result.getDate("DELIVERY_DATE"));
				   order.setProductName(result.getString("PRODUCT_NAME"));
				   order.setSupplierName(result.getString("SUPPLIER_NAME"));
				   order.setQuantity(result.getInt("QUANTITY"));
				   order.setUnitPrice(result.getFloat("UNIT_PRICE"));
				   order.setTotalPrice(result.getFloat("TOTAL_PRICE"));
	   					    
			    return order;
			
			   }
		  });
	   return orderInfoList;
	}

	public List<Order> getOrderDetailsToEdit(String orderId) {
		// TODO Auto-generated method stub
		String query = "select * from ORDER_DETAILS_TABLE where ORDER_ID = '"+orderId+"'";
		System.out.println("query to fetch details: "+query);	
		
		List<Order> orderInfoList = jdbcTemplate.query(query, new RowMapper<Order>(){

			public Order mapRow(ResultSet result, int rowNum) throws SQLException {
				Order order = new Order();
				   order.setOrderId(result.getString("ORDER_ID"));
				   order.setUserId(result.getString("USER_ID"));
				   order.setCustomerId(result.getString("CUSTOMER_ID"));
				   order.setOrderDate(result.getDate("ORDER_DATE"));
				   order.setDeliveryDate(result.getDate("DELIVERY_DATE"));
				   order.setProductName(result.getString("PRODUCT_NAME"));
				   order.setSupplierName(result.getString("SUPPLIER_NAME"));
				   order.setQuantity(result.getInt("QUANTITY"));
				   order.setUnitPrice(result.getFloat("UNIT_PRICE"));
				   order.setTotalPrice(result.getFloat("TOTAL_PRICE"));
	   					    
			    return order;
			
			   }
		  });
	  return orderInfoList;
	}

	public boolean editOrder(Order order,int editQuant) {
		// TODO Auto-generated method stub
		String insertQuery = "update ORDER_DETAILS_TABLE set DELIVERY_DATE = :del, PRODUCT_NAME = :pname, SUPPLIER_NAME = :sname, QUANTITY = :quant ,"
				+ " UNIT_PRICE = :uprice, TOTAL_PRICE = :tprice WHERE ORDER_ID = :oid";
		String editQuery = "update product set STOCK = STOCK - :quant + "+ editQuant +" where PRODUCT_NAME = :pname and SUPPLIER_NAME = :sname";
				
		   Map<String, Object> parameters = new HashMap<String, Object>();
		   
		   parameters.put("oid", order.getOrderId());
		   parameters.put("uid", order.getUserId());
		   parameters.put("cid", order.getCustomerId());
		   parameters.put("odate", order.getOrderDate());
		   parameters.put("del", order.getDeliveryDate());
		   parameters.put("pname", order.getProductName());
		   parameters.put("sname", order.getSupplierName());
		   parameters.put("quant", order.getQuantity());
		   parameters.put("uprice", order.getUnitPrice());
		   parameters.put("tprice", order.getTotalPrice());
		   
		   int rowcount = jdbcTemplate.update(insertQuery, parameters);
		   int stockUpdate = jdbcTemplate.update(editQuery, parameters);
		
		if(rowcount == 1){
			if(stockUpdate==1){
				return true;
			}
			else{
				//delete the order row
				return false;
			}
		}
		else{
			return false;
		}
	}

	public boolean deleteOrder(String orderId) {
		// TODO Auto-generated method stub
		String query = "Delete from ORDER_DETAILS_TABLE where ORDER_ID = ? ";
		System.out.println("delete query: "+ query);
		int rowCount = jdbcTemplate.update(query, orderId);
		if(rowCount >0){
			return true;
		}
		else{
			return false;
		}	
	}
	
}
