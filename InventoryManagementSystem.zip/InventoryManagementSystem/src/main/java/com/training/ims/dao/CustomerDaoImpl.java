package com.training.ims.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.training.ims.model.CustomerModel;

@SuppressWarnings("deprecation")
public class CustomerDaoImpl implements ICustomerDao{

	private SimpleJdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		// TODO Auto-generated method stub
		this.jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	public boolean addCustomer(CustomerModel customerModel) {
		// TODO Auto-generated method stub		
		  
		  Map<String, Object> parameters = new HashMap<String, Object>();
			
		    parameters.put("custId", customerModel.getCustomerId());
			parameters.put("fname", customerModel.getCustomerFirstName());
			parameters.put("lname", customerModel.getCustomerLastName());
			parameters.put("phno", customerModel.getCustomerPhoneNumber());
			parameters.put("email", customerModel.getCustomerEmail());
			parameters.put("addr", customerModel.getCustomerAddress());
			parameters.put("city", customerModel.getCustomerCity());
			parameters.put("state", customerModel.getCustomerState());
			parameters.put("pincode", customerModel.getCustomerPinCode());
			
			int rowcount = jdbcTemplate.update(SQLQueries.CUST_INSERT, parameters);
			
			if(rowcount == 1){
				Map<String, Object> logTableParameter = new HashMap<String, Object>();
				logTableParameter.put("id", customerModel.getCustomerId());
				logTableParameter.put("uname", customerModel.getCustomerFirstName());
				logTableParameter.put("pass", customerModel.getCustomerPassword());
				logTableParameter.put("role", "customer");	
				
				int logcount = jdbcTemplate.update(SQLQueries.ROLE_INSRT, logTableParameter);
				if(logcount == 1){
					return true;
				}
				else{
					return false;
				}				
			}
			else{
				return false;
			}
	}

	public boolean deleteCustomer(String customerId) {
		// TODO Auto-generated method stub
		String query = "Delete from customer where CUSTOMER_ID = ? ";
		System.out.println("delete query: "+ query);
		int rowCount = jdbcTemplate.update(query, customerId);
		if(rowCount >0){
			return true;
		}
		else{
			return false;
		}	
	}

	public List<CustomerModel> getCustomers() {
		// TODO Auto-generated method stub
		String query = "select CUSTOMER_ID,FIRST_NAME,LAST_NAME,PHONE_NUMBER,EMAIL,ADDRESS,CITY,STATE,PINCODE from customer";
		 
		  List<CustomerModel> customerInfoList = jdbcTemplate.query(query, new RowMapper<CustomerModel>(){

			   public CustomerModel mapRow(ResultSet result, int rowNum) throws SQLException {
			    CustomerModel customer = new CustomerModel();
			    customer.setCustomerId(result.getString("CUSTOMER_ID"));
			    customer.setCustomerFirstName(result.getString("FIRST_NAME"));
			    customer.setCustomerLastName(result.getString("LAST_NAME"));
			    customer.setCustomerPhoneNumber(result.getString("PHONE_NUMBER"));
			    customer.setCustomerEmail(result.getString("EMAIL"));
			    customer.setCustomerAddress(result.getString("ADDRESS"));
			    customer.setCustomerCity(result.getString("CITY"));
			    customer.setCustomerState(result.getString("STATE"));
			    customer.setCustomerPinCode(result.getInt("PINCODE"));
			    
			    return customer;
			
			   }
		  });
	  return customerInfoList;
	 }

	public List<CustomerModel> getCustomerDetailsToEdit(String custId) {
		// TODO Auto-generated method stub
		String query = "select * from customer where CUSTOMER_ID = '"+custId+"'";
		System.out.println("query to fetch details: "+query);	
		List<CustomerModel> customerInfoList = jdbcTemplate.query(query, new RowMapper<CustomerModel>(){

			public CustomerModel mapRow(ResultSet result, int rowNum) throws SQLException {
				CustomerModel customer = new CustomerModel();
				customer.setCustomerId(result.getString("CUSTOMER_ID"));
				customer.setCustomerFirstName(result.getString("FIRST_NAME"));
				customer.setCustomerLastName(result.getString("LAST_NAME"));
				customer.setCustomerPhoneNumber(result.getString("PHONE_NUMBER"));
				customer.setCustomerEmail(result.getString("EMAIL"));
				customer.setCustomerAddress(result.getString("ADDRESS"));
				customer.setCustomerCity(result.getString("CITY"));
				customer.setCustomerState(result.getString("STATE"));
				customer.setCustomerPinCode(result.getInt("PINCODE"));
				System.out.println(customer);
				return customer;
			}
		});
		return customerInfoList;
	}

	public boolean editCustomer(CustomerModel customerModel) {
		// TODO Auto-generated method stub
		String editQuery = "update customer set FIRST_NAME = :fname, LAST_NAME = :lname, PHONE_NUMBER = :phno, EMAIL = :email, ADDRESS = :addr, CITY = :city, STATE = :state, PINCODE = :pincode "
				+ " WHERE CUSTOMER_ID = :custId ";
		  
		  Map<String, Object> parameters = new HashMap<String, Object>();
			
		    parameters.put("custId", customerModel.getCustomerId());
			parameters.put("fname", customerModel.getCustomerFirstName());
			parameters.put("lname", customerModel.getCustomerLastName());
			parameters.put("phno", customerModel.getCustomerPhoneNumber());
			parameters.put("email", customerModel.getCustomerEmail());
			parameters.put("addr", customerModel.getCustomerAddress());
			parameters.put("city", customerModel.getCustomerCity());
			parameters.put("state", customerModel.getCustomerState());
			parameters.put("pincode", customerModel.getCustomerPinCode());
			
			int rowcount = jdbcTemplate.update(editQuery, parameters);
			
			if(rowcount == 1){
				return true;			
			}
			else{
				return false;
			}
	}
}

