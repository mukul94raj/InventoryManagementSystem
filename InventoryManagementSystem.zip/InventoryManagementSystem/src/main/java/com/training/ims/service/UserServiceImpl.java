package com.training.ims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.ims.dao.IUserDao;
import com.training.ims.model.UserModel;

public class UserServiceImpl implements IUserService{
	
	@Autowired
	private IUserDao userDao;

	public boolean addUserInfo(UserModel userModel) {
		// TODO Auto-generated method stub
		return userDao.addUserInfo(userModel);
	}

	public boolean deletingUser(String userId) {
		// TODO Auto-generated method stub
		return userDao.deletingUser(userId) ;
	}

	public List<UserModel> getUsers() {
		// TODO Auto-generated method stub
		return userDao.getUsers();
	}

	public List<UserModel> getUserDetailsToEdit(String userId) {
		// TODO Auto-generated method stub
		return userDao.getUserDetailsToEdit(userId);
	}
	
	public boolean editUser(UserModel userModel) {
		// TODO Auto-generated method stub
		return userDao.editUser(userModel);
	}

}
