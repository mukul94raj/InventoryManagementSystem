/*package com.training.ims.dao;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.training.ims.model.LoginModel;

public class LoginDaoImpl implements ILoginDao{

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
 
	@SuppressWarnings("deprecation")
	public boolean authenticateUser(LoginModel loginModel) throws SQLException {
		
		boolean userExists = false;
		int rowcount = 0;
		
		try{
		rowcount = jdbcTemplate.queryForInt("select count(*) from LOGIN_TABLE " +
				" where identity = ? and password = ? and role = ?",
				loginModel.getIdentity(),loginModel.getPassword(),loginModel.getRole());
		}
		catch (NullPointerException e) {
			// TODO: handle exception
			e.printStackTrace();
			HttpServletResponse response;
			//response.sendRedirect("doLogin");
		}
		if(rowcount==1){
			userExists = true;
		}
		return userExists;
	}
		
}
*/

package com.training.ims.dao;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.training.ims.model.LoginModel;

public class LoginDaoImpl implements ILoginDao{

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
 
	@SuppressWarnings("deprecation")
	public boolean authenticateUser(LoginModel loginModel) throws SQLException {
		
		boolean userExists = false;
		int rowcount = 0;
		
		try{
		rowcount = jdbcTemplate.queryForInt("select count(*) from LOGIN_TABLE " +
				" where identity = ? and password = ? ",loginModel.getIdentity(),loginModel.getPassword());
		}
		catch (NullPointerException e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}
		if(rowcount==1){
			userExists = true;
		}
		return userExists;
	}
		
	public String setRoleOfUser(LoginModel loginModel){

		String role = null;
		String query = "select ROLE from LOGIN_TABLE where IDENTITY = '" + loginModel.getIdentity() + "'";
		
		role = (String)jdbcTemplate.queryForObject(query,String.class);
		
		return role;
	}

	public String setUserName(LoginModel loginModel) {
		// TODO Auto-generated method stub
		String name = null;
		String query = "select username from LOGIN_TABLE where IDENTITY = '" + loginModel.getIdentity() + "'";
		
		name = (String)jdbcTemplate.queryForObject(query,String.class);
		
		return name;
	}
}

