package com.training.ims.service;

import java.sql.SQLException;

import com.training.ims.model.LoginModel;

public interface ILoginService {
	public abstract boolean authenticateUser(LoginModel loginModel) throws SQLException;
	public abstract String setRoleOfUser(LoginModel loginModel);
	public abstract String setUserName(LoginModel loginModel);
}
