package com.training.ims.dao;

import java.sql.SQLException;

import javax.sql.DataSource;

import com.training.ims.model.LoginModel;


public interface ILoginDao {
	public abstract void setDataSource(DataSource dataSource);
	public abstract boolean authenticateUser(LoginModel loginModel) throws SQLException;
	public abstract String setRoleOfUser(LoginModel loginModel);
	public abstract String setUserName(LoginModel loginModel);
}
