package com.training.ims.dao;

public interface SQLQueries {
	
	String CUST_INSERT = "insert into customer values(:custId, :fname, :lname, :phno, :email, :addr, :city, :state, :pincode)";
	String ROLE_INSRT = "insert into LOGIN_TABLE values(:id,:uname,:pass,:role)";

}