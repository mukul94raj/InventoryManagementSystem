package com.training.ims.controller;

import java.sql.SQLException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.training.ims.model.LoginModel;
import com.training.ims.service.ILoginService;

@Controller
@SessionAttributes("loginModel")
public class LoginController {

	@Autowired
	private ILoginService loginService;
	
	static Logger logger = Logger.getLogger(LoginController.class);
	
	@RequestMapping(value="/doLogin",method = RequestMethod.GET)
	public ModelAndView LoginProcess(HttpServletRequest request,HttpServletResponse response,LoginModel loginModel){
		
	    logger.info("The login page is being loaded");
		
    	ModelAndView model=new ModelAndView("loginpage");
    	model.addObject("loginModel",loginModel);
    	return model;
    	
    }
		
	@RequestMapping(value="/doLogin",method = RequestMethod.POST)
	public ModelAndView doLogin(HttpServletRequest request,HttpServletResponse response,@ModelAttribute("loginModel") @Valid LoginModel loginModel,BindingResult result) throws SQLException {

		logger.info("The Login Credentials are sent to server");
        
		ModelAndView view = new ModelAndView("loginpage");
		
		logger.warn("Authentication has to be done");
		
		try{
			if(!loginService.authenticateUser(loginModel)) {
				result.addError(new ObjectError("err", "Invalid Credentials"));
			} 
			else {
				
				String role = loginService.setRoleOfUser(loginModel);
				loginModel.setRole(role);
				
				String user = loginService.setUserName(loginModel);
				loginModel.setUsername(user);
				
				//Adding Role to session attribute
				HttpSession session = request.getSession();
				session.setAttribute("loginModel", loginModel);
				
				logger.info("A cookie is being set with lifespan of 1000 seconds");
				
				Cookie ims = new Cookie("ims", "PROJECT");
				ims.setMaxAge(3600);
				response.addCookie(ims);
				
				logger.info("The welcome page is being loaded for "+loginModel.getIdentity()+" with "+loginModel.getRole()+ "access");
				
				String attach = "welcome";	//name of jsp file		
				view.setViewName("successview");
				view.addObject("attachModel",attach);
				logger.info("Successfully Logged In");
			}
		}
		catch (NullPointerException e) {
			// TODO: handle exception
			logger.error("An exception has occured while checking the login credentials in database");
		}
		return view;
	}
	
	@RequestMapping(value="/doLoginDirect",method = RequestMethod.GET)
	public ModelAndView LoginProcessDone(HttpServletRequest request,HttpServletResponse response,LoginModel loginModel){
				
		logger.info("The user had already logged in. redirecting directly to welcome page");
		
		ModelAndView view = new ModelAndView();
		String attach = "welcome";	//name of jsp file		
		view.setViewName("successview");
		view.addObject("attachModel",attach);		
    	return view;
    }

	@RequestMapping(value="/logout")
	public String logout(HttpSession session) {	
		
		logger.info("The User is logging out. The session is being removed and login page is being loaded.");
		
		session.removeAttribute("loginModel");
		session.invalidate();

		return "indexLog";
    }
}
