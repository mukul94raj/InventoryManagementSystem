package com.training.ims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.ims.dao.IOrderDao;
import com.training.ims.model.Order;

public class OrderServiceImpl implements IOrderService{

	@Autowired
	private IOrderDao orderDao;
	
	public boolean addOrder(Order order) {
		// TODO Auto-generated method stub
		return orderDao.addOrder(order);
	}

	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return orderDao.getOrders();
	}

	public List<Order> getOrderDetailsToEdit(String orderId) {
		// TODO Auto-generated method stub
		return orderDao.getOrderDetailsToEdit(orderId);
	}

	public boolean editOrder(Order order,int editQuant) {
		// TODO Auto-generated method stub
		return orderDao.editOrder(order,editQuant);
	}

	public boolean deleteOrder(String orderId) {
		// TODO Auto-generated method stub
		return orderDao.deleteOrder(orderId);
	}

}
