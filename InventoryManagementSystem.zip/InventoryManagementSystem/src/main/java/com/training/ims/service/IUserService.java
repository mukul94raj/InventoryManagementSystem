package com.training.ims.service;

import java.util.List;

import com.training.ims.model.UserModel;

public interface IUserService {
	public abstract boolean addUserInfo(UserModel userModel);
	public abstract boolean deletingUser(String userId);
	public abstract List<UserModel> getUsers();
	public abstract List<UserModel> getUserDetailsToEdit (String userId);
	public abstract boolean editUser(UserModel userModel);
}
