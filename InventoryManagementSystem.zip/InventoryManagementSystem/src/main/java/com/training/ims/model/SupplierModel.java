package com.training.ims.model;

public class SupplierModel {
	private String supplierId;
	private String supplierFirstName;
	private String supplierLastName;
	
	private String supplierPhoneNumber;
	
	private String supplierEmail;
	
	private String supplierAddress;
	private String supplierCity;
	private String supplierState;
	
	private int supplierPinCode;
	
	private String supplierPassword;

	public String getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}

	public String getSupplierFirstName() {
		return supplierFirstName;
	}

	public void setSupplierFirstName(String supplierFirstName) {
		this.supplierFirstName = supplierFirstName;
	}

	public String getSupplierLastName() {
		return supplierLastName;
	}

	public void setSupplierLastName(String supplierLastName) {
		this.supplierLastName = supplierLastName;
	}

	public String getSupplierPhoneNumber() {
		return supplierPhoneNumber;
	}

	public void setSupplierPhoneNumber(String supplierPhoneNumber) {
		this.supplierPhoneNumber = supplierPhoneNumber;
	}

	public String getSupplierEmail() {
		return supplierEmail;
	}

	public void setSupplierEmail(String supplierEmail) {
		this.supplierEmail = supplierEmail;
	}

	public String getSupplierAddress() {
		return supplierAddress;
	}

	public void setSupplierAddress(String supplierAddress) {
		this.supplierAddress = supplierAddress;
	}

	public String getSupplierCity() {
		return supplierCity;
	}

	public void setSupplierCity(String supplierCity) {
		this.supplierCity = supplierCity;
	}

	public String getSupplierState() {
		return supplierState;
	}

	public void setSupplierState(String supplierState) {
		this.supplierState = supplierState;
	}

	public int getSupplierPinCode() {
		return supplierPinCode;
	}

	public void setSupplierPinCode(int supplierPinCode) {
		this.supplierPinCode = supplierPinCode;
	}
	
	public String getSupplierPassword() {
		return supplierPassword;
	}

	public void setSupplierPassword(String supplierPassword) {
		this.supplierPassword = supplierPassword;
	}

	@Override
	public String toString() {
		return "SupplierModel [supplierId=" + supplierId + ", supplierFirstName=" + supplierFirstName
				+ ", supplierLastName=" + supplierLastName + ", supplierPhoneNumber=" + supplierPhoneNumber
				+ ", supplierEmail=" + supplierEmail + ", supplierAddress=" + supplierAddress + ", supplierCity="
				+ supplierCity + ", supplierState=" + supplierState + ", supplierPinCode=" + supplierPinCode + "]";
	}


}
