package com.training.ims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.ims.dao.ICustomerDao;
import com.training.ims.model.CustomerModel;

public class CustomerServiceImpl implements ICustomerService{
	
	@Autowired
	private ICustomerDao customerDao;
	
	public boolean addCustomer(CustomerModel customerModel) {
		// TODO Auto-generated method stub
		return customerDao.addCustomer(customerModel);
	}

	public boolean deleteCustomer(String customerId) {
		
		return customerDao.deleteCustomer(customerId);
	}

	public List<CustomerModel> getCustomers() {
		
		return customerDao.getCustomers();
	}

	public List<CustomerModel> getCustomerDetailsToEdit(String custId) {
		// TODO Auto-generated method stub
		return customerDao.getCustomerDetailsToEdit(custId);
	}


	public boolean editCustomer(CustomerModel customerModel) {
		// TODO Auto-generated method stub
		return customerDao.editCustomer(customerModel);
	}

}
