package com.training.ims.dao;

import java.util.List;

import javax.sql.DataSource;


import com.training.ims.model.SupplierModel;

public interface ISupplierDao {
	public abstract void setDataSource(DataSource dataSource);
	public abstract boolean addSupplier(SupplierModel supplierModel);
	public abstract boolean deleteSupplier(String suppId);
	public abstract List<SupplierModel> getSuppliers();
	public abstract List<SupplierModel> getSupplierDetailsToEdit (String custId);
	public abstract boolean editSupplier(SupplierModel supplierModel);

}
