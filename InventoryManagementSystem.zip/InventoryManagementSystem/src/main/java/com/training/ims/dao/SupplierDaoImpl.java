package com.training.ims.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import com.training.ims.model.SupplierModel;

@SuppressWarnings("deprecation")
public class SupplierDaoImpl  implements ISupplierDao{
	private SimpleJdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		// TODO Auto-generated method stub
		this.jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	public boolean addSupplier(SupplierModel supplierModel) {
		// TODO Auto-generated method stub
		 String insertQuery = "insert into supplier values(:suppId, :fnmae, :lname, :phno, :email, :addr, :city, :state, :pincode)";
		  
		  Map<String, Object> parameters = new HashMap<String, Object>();
			
		    parameters.put("suppId", supplierModel.getSupplierId());
			parameters.put("fnmae", supplierModel.getSupplierFirstName());
			parameters.put("lname", supplierModel.getSupplierLastName());
			parameters.put("phno", supplierModel.getSupplierPhoneNumber());
			parameters.put("email", supplierModel.getSupplierEmail());
			parameters.put("addr", supplierModel.getSupplierAddress());
			parameters.put("city", supplierModel.getSupplierCity());
			parameters.put("state", supplierModel.getSupplierState());
			parameters.put("pincode", supplierModel.getSupplierPinCode());
			
			int rowcount = jdbcTemplate.update(insertQuery, parameters);
			
			if(rowcount == 1){
				return true;
			}
			else{
				return false;
			}
	}
	
	
	public boolean deleteSupplier(String suppId) {
		// TODO Auto-generated method stub
		String query = "Delete from supplier where SUPPLIER_ID = '"+suppId+"'";
		System.out.println("delete query: "+ query);
		int rowCount = jdbcTemplate.update(query);
		if(rowCount >0){
			return true;
		}
		else{
			return false;
		}	
	}

	
	public List<SupplierModel> getSuppliers() {
		  // TODO Auto-generated method stub
		  String query = "select SUPPLIER_ID,FIRST_NAME,LAST_NAME,PHONE_NUMBER,EMAIL,ADDRESS,CITY,STATE,PINCODE from supplier";
		  List<SupplierModel> supplierInfoList = jdbcTemplate.query(query, new RowMapper<SupplierModel>(){

				public SupplierModel mapRow(ResultSet result, int rowNum) throws SQLException {
					SupplierModel supplier = new SupplierModel();
					supplier.setSupplierId(result.getString("SUPPLIER_ID"));
					supplier.setSupplierFirstName(result.getString("FIRST_NAME"));
					supplier.setSupplierLastName(result.getString("LAST_NAME"));
					supplier.setSupplierPhoneNumber(result.getString("PHONE_NUMBER"));
					supplier.setSupplierEmail(result.getString("EMAIL"));
					supplier.setSupplierAddress(result.getString("ADDRESS"));
					supplier.setSupplierCity(result.getString("CITY"));
					supplier.setSupplierState(result.getString("STATE"));
					supplier.setSupplierPinCode(result.getInt("PINCODE"));
					
					return supplier;
				}
				
			});
			return supplierInfoList;
		}

	public List<SupplierModel> getSupplierDetailsToEdit(String suppId) {
		// TODO Auto-generated method stub
		String query = "select SUPPLIER_ID,FIRST_NAME,LAST_NAME,PHONE_NUMBER,EMAIL,ADDRESS,CITY,STATE,PINCODE from supplier where SUPPLIER_ID = '"+suppId+"'";
		System.out.println("query to fetch details: "+query);	
		List<SupplierModel> supplierInfoList = jdbcTemplate.query(query, new RowMapper<SupplierModel>(){

			public SupplierModel mapRow(ResultSet result, int rowNum) throws SQLException {
				SupplierModel supplier = new SupplierModel();
				supplier.setSupplierId(result.getString("SUPPLIER_ID"));
				supplier.setSupplierFirstName(result.getString("FIRST_NAME"));
				supplier.setSupplierLastName(result.getString("LAST_NAME"));
				supplier.setSupplierPhoneNumber(result.getString("PHONE_NUMBER"));
				supplier.setSupplierEmail(result.getString("EMAIL"));
				supplier.setSupplierAddress(result.getString("ADDRESS"));
				supplier.setSupplierCity(result.getString("CITY"));
				supplier.setSupplierState(result.getString("STATE"));
				supplier.setSupplierPinCode(result.getInt("PINCODE"));
				System.out.println(supplier);
				return supplier;
			}
		});
		return supplierInfoList;
	}

	public boolean editSupplier(SupplierModel supplierModel) {
		// TODO Auto-generated method stub
		String editQuery = "update supplier set FIRST_NAME = :fname, LAST_NAME = :lname, PHONE_NUMBER = :phno, EMAIL = :email, "
				+ "ADDRESS = :addr, CITY = :city, STATE = :state, PINCODE = :pincode WHERE SUPPLIER_ID = :custId ";
		  
		  Map<String, Object> parameters = new HashMap<String, Object>();
			
		    parameters.put("custId", supplierModel.getSupplierId());
			parameters.put("fname", supplierModel.getSupplierFirstName());
			parameters.put("lname", supplierModel.getSupplierLastName());
			parameters.put("phno", supplierModel.getSupplierPhoneNumber());
			parameters.put("email", supplierModel.getSupplierEmail());
			parameters.put("addr", supplierModel.getSupplierAddress());
			parameters.put("city", supplierModel.getSupplierCity());
			parameters.put("state", supplierModel.getSupplierState());
			parameters.put("pincode", supplierModel.getSupplierPinCode());
			
			int rowcount = jdbcTemplate.update(editQuery, parameters);
			
			if(rowcount == 1){
				return true;			
			}
			else{
				return false;
			}
	}

	
}
		
	



