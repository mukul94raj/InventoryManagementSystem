package com.training.ims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.training.ims.dao.ISupplierDao;
import com.training.ims.model.SupplierModel;

public class SupplierServiceImpl implements ISupplierService {
	@Autowired 
	private ISupplierDao supplierDao;

	public boolean addSupplier(SupplierModel supplierModel) {
		
		return supplierDao.addSupplier(supplierModel);
	}


	public boolean deleteSupplier(String suppId) {
		
		return supplierDao.deleteSupplier(suppId);
	}

	public List<SupplierModel> getSuppliers() {
		// TODO Auto-generated method stub
		return supplierDao.getSuppliers();
	}

	public List<SupplierModel> getSupplierDetailsToEdit(String custId) {
		// TODO Auto-generated method stub
		return supplierDao.getSupplierDetailsToEdit(custId);
	}

	public boolean editSupplier(SupplierModel supplierModel) {
		// TODO Auto-generated method stub
		return supplierDao.editSupplier(supplierModel);
	}
	
}
