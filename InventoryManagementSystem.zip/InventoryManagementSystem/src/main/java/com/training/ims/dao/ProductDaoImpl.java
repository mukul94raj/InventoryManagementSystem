package com.training.ims.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.ResultSet;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

import com.training.ims.model.ProductModel;

@SuppressWarnings("deprecation")
public class ProductDaoImpl implements IProductDao{

	private SimpleJdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		// TODO Auto-generated method stub
		this.jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	public boolean addProduct(ProductModel productModel) {
		// TODO Auto-generated method stub
		String insertQuery = "insert into product values(?, ?, ?, ?, ?, ?)";
		int rowcount = jdbcTemplate.update(insertQuery, productModel.getProductId(), productModel.getProductName(), 
								productModel.getSupplierName(),productModel.getUnitPrice(), productModel.getStock(), productModel.getProductDescription());
		
		if(rowcount == 1){
			return true;
		}
		else{
			return false;
		}
	}
	

	public List<ProductModel> getProductsList() {
		
		String query = "select PRODUCT_ID,PRODUCT_NAME,SUPPLIER_NAME,UNIT_PRICE,STOCK,PRODUCT_DESCRIPTION from PRODUCT";
		List<ProductModel> productList = new ArrayList<ProductModel>();
		productList = jdbcTemplate.query(query, new RowMapper<ProductModel>(){

			public ProductModel mapRow(ResultSet result, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				ProductModel productModel = new ProductModel();
				
				productModel.setProductId(result.getString("PRODUCT_ID"));
				productModel.setProductName(result.getString("PRODUCT_NAME"));
				productModel.setSupplierName(result.getString("SUPPLIER_NAME"));
				productModel.setUnitPrice(result.getFloat("UNIT_PRICE"));
				productModel.setStock(result.getInt("STOCK"));
				productModel.setProductDescription(result.getString("PRODUCT_DESCRIPTION"));
				
				return productModel;
			}
		});	
		return productList;
	}

	public boolean deleteProduct(String productId) {
		String query = "Delete from product where PRODUCT_ID = '"+productId+"'";
		System.out.println("delete query: "+ query);
		int rowCount = jdbcTemplate.update(query);
		if(rowCount >0){
			return true;
		}
		else
			return false;
	}

	public List<ProductModel> getProductDetailsToEdit(String productId) {
		 // TODO Auto-generated method stub
		  String query = "select * from product where PRODUCT_ID = '"+productId+"'";
		  System.out.println("query to fetch details: "+query); 
		  List<ProductModel> productInfoList = jdbcTemplate.query(query, new RowMapper<ProductModel>(){

		   public ProductModel mapRow(ResultSet result, int rowNum) throws SQLException {
		    ProductModel productModel = new ProductModel();
		    productModel.setProductId(result.getString("PRODUCT_ID"));
		    productModel.setProductName(result.getString("PRODUCT_NAME"));
		    productModel.setSupplierName(result.getString("SUPPLIER_NAME"));
		    productModel.setUnitPrice(result.getFloat("UNIT_PRICE"));
		    productModel.setStock(result.getInt("STOCK"));
		    productModel.setProductDescription(result.getString("PRODUCT_DESCRIPTION"));
		    System.out.println(productModel);
		    
		    return productModel;
		   }
		  });
		  return productInfoList;
	}

	public boolean editProduct(ProductModel productModel) {
		  //TODO Auto-generated method stub
		  //String insertQuery = "insert into customer values(:custId, :fnmae, :lname, :phno, :email, :addr, :city, :state, :pincode)";
		  String editQuery = "update product set PRODUCT_NAME = :pname, SUPPLIER_NAME = :sname, UNIT_PRICE = :uprice, STOCK = :stock, "
		  		+ "PRODUCT_DESCRIPTION = :pdec WHERE PRODUCT_ID = :prodId ";
		    
		   Map<String, Object> parameters = new HashMap<String, Object>();
		   
		   parameters.put("prodId", productModel.getProductId());
		   parameters.put("pname", productModel.getProductName());
		   parameters.put("sname", productModel.getSupplierName());
		   parameters.put("uprice", productModel.getUnitPrice());
		   parameters.put("stock", productModel.getStock());
		   parameters.put("pdec", productModel.getProductDescription());
		   
		   
		   int rowcount = jdbcTemplate.update(editQuery, parameters);
		   
		   if(rowcount == 1){
		    return true;   
		   }
		   else{
		    return false;
		   }
	}
}
