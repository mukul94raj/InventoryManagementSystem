package com.training.ims.model;

import org.hibernate.validator.constraints.NotEmpty;

public class LoginModel {
	
	private String Identity;
	
	@NotEmpty(message="LoginId cannot be empty")
	private String username;
	
	@NotEmpty(message="Password cannot be empty")
	private String password;
	
	private String role;
	
	public LoginModel() {
		// TODO Auto-generated constructor stub
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getIdentity() {
		return Identity;
	}

	public void setIdentity(String identity) {
		Identity = identity;
	}
	
	
	
}
