package com.training.ims.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.training.ims.model.CustomerModel;
import com.training.ims.service.ICustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	private ICustomerService customerService;
	
	static Logger logger = Logger.getLogger(CustomerController.class);
	
	@RequestMapping(value="/addCustomer",method = RequestMethod.GET)
	public ModelAndView AddProcess(HttpServletRequest request,HttpServletResponse response,ModelAndView model,CustomerModel customerModel){
		
		logger.info("A Form is displayed to add a customer");
		
		List<CustomerModel> customerList = customerService.getCustomers();
		List<String> customerIdList = new ArrayList<String>();
		for(int i = 0; i<customerList.size();i++){
			customerIdList.add(customerList.get(i).getCustomerId());
		}
		
		String attach = "addcustomer";
		model.setViewName("successview");
		model.addObject("ListOfIds",customerIdList);
    	model.addObject("attachModel",attach);    	
    	return model;
    	
    }	
	
	
	@RequestMapping(value="/addCust",method = RequestMethod.POST)
	public ModelAndView Addition(@ModelAttribute("customerModel") @Valid CustomerModel customerModel,BindingResult result) {
		
		logger.info("An add customer form was filled and submitted");
		logger.warn("The data from add customer form is being sent to the database");
		
		boolean addedStatus = false;
		
		try{
			addedStatus = customerService.addCustomer(customerModel);
		}
		catch (NullPointerException e) {
			logger.error("An occurred while fetching data from database");
			logger.debug("A Null pointer Exception has arised",e);
		}
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach);   
    	List<CustomerModel> customerList = customerService.getCustomers();
    	viewModel.addObject("reattachModel", "viewCustomers");
    	viewModel.addObject("customerinfo",customerList);    
				
		if(addedStatus){
			logger.info("Customer successfully added");
			viewModel.addObject("message", "Customer successfully added");	
		}
		else
		{
			viewModel.addObject("message", "Sorry! Customer Cannot be added");
			logger.warn("Customer cannot be added");
		}
		return viewModel;
	}
	
	
	@RequestMapping(value = "/viewCustomer", method = RequestMethod.GET)
	public ModelAndView getCustomers(){
		
		logger.info("Customer data is being viewed");
		
		List<CustomerModel> customerList = customerService.getCustomers();
		
		String attach = "viewCustomers";
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);   
    	model.addObject("customerinfo",customerList);    	
    	return model;
    	
	}
	
	
	@RequestMapping(value = "/deleteCust", method = RequestMethod.POST)
	public ModelAndView delete(@RequestParam("custId") String customerId ){
		
		logger.info("The customer with Id: "+customerId+" is being deleted from the database");
		logger.warn("The data from add customer form is being sent to the database");	
		
		boolean isdeleted = false;
		
		try{
			isdeleted = customerService.deleteCustomer(customerId);
		}
		catch (NullPointerException e) {
			// TODO: handle exception
			logger.error("An error has occurred while deleting customer data from datbase");
		}
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach);   
    	List<CustomerModel> customerList = customerService.getCustomers();
    	viewModel.addObject("reattachModel", "viewCustomers");
    	viewModel.addObject("customerinfo",customerList); 
		
		if(isdeleted){
			viewModel.addObject("message","Customer Data deleted successfully"); 
			logger.info("Customer Data deleted successfully");
		}
		else{
			viewModel.addObject("message", "Sorry! Customer Data cannot be deleted");  
			logger.warn("Customer Data cannot be deleted");
		}		
		return viewModel;
	}
	
	@RequestMapping(value = "/editCustomerDetails", method = RequestMethod.POST)
	public ModelAndView editCustomerDetails(CustomerModel customerModel,BindingResult result,@RequestParam("custId") String customerId ){
		
		logger.info("Data of a customer with id "+customerId  +" to be edited");
		
		List<CustomerModel> customerList = customerService.getCustomerDetailsToEdit(customerId);
		
		String attach = "customerInfoToEdit" ;
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);   
    	model.addObject("customerinfo",customerList);    	
    	return model;
	}
	
	@RequestMapping(value = "/editCust", method = RequestMethod.POST)
	public ModelAndView editCustomer(@ModelAttribute("customerModel") @Valid CustomerModel customerModel,BindingResult result){
		
		boolean isedited = false;
		
		try{
			isedited = customerService.editCustomer(customerModel);
		}
		catch (NullPointerException e) {
			// TODO: handle exception
			logger.error("An error has occurred while editing customer data from datbase");
		}
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach);   
    	List<CustomerModel> customerList = customerService.getCustomers();
    	viewModel.addObject("reattachModel", "viewCustomers");
    	viewModel.addObject("customerinfo",customerList); 
		
		if(isedited){
			viewModel.addObject("message","Customer Data edited successfully"); 
			logger.info("Customer Data edited successfully");
		}
		else{
			viewModel.addObject("message", "Sorry!Customer Data cannot be edited");  
			logger.warn("Sorry!Customer Data cannot be edited");
		}		
		return viewModel;
	}
	
}
