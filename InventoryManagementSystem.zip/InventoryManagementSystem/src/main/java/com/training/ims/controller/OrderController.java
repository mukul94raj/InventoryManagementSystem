package com.training.ims.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.training.ims.model.CustomerModel;
import com.training.ims.model.Order;
import com.training.ims.model.ProductModel;
import com.training.ims.model.UserModel;

import com.training.ims.service.ICustomerService;
import com.training.ims.service.IOrderService;
import com.training.ims.service.IProductService;
import com.training.ims.service.IUserService;


@Controller
public class OrderController {
	
	@Autowired
	private IOrderService orderService;
	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private ICustomerService customerService;
	
	@Autowired
	private IUserService userService;
	
	static Logger logger = Logger.getLogger(LoginController.class);
	
	@RequestMapping(value="/createOrder", method = RequestMethod.GET)
	public ModelAndView AddProcess(HttpServletRequest request, HttpServletResponse response, ModelAndView model, Order order){		
		
		logger.info("A Form is displayed to create an order");
		
		List<Order> orderList = orderService.getOrders();
		List<String> orderIdList = new ArrayList<String>();
		for(int i = 0; i<orderList.size();i++){
			orderIdList.add(orderList.get(i).getOrderId());
		}
		
		//String attach = "createorder";
		String attach = "addorder";
		model.setViewName("successview");
		model.addObject("ListOfIds",orderIdList);
		model.addObject("attachModel", attach);
		
		List<ProductModel> productList = productService.getProductsList();
		List<CustomerModel> customerList = customerService.getCustomers();
		List<UserModel> userList = userService.getUsers();
		
		List<String> productNameList = new ArrayList<String>();
		List<String> supplierNameList = new ArrayList<String>();
		List<Integer> stockList = new ArrayList<Integer>();
		List<Float> unitPriceList = new ArrayList<Float>();
		
		List<String> customerIdList = new ArrayList<String>();
		List<String> customerNameList = new ArrayList<String>();
		
		List<String> userIdList = new ArrayList<String>();
		List<String> userNameList = new ArrayList<String>();
		
		for(int i=0;i<productList.size();i++){
			
			productNameList.add(productList.get(i).getProductName());
			supplierNameList.add(productList.get(i).getSupplierName());
			stockList.add(productList.get(i).getStock());
			unitPriceList.add(productList.get(i).getUnitPrice());
			
		}
		
		for(int i=0;i<customerList.size();i++){
			
			customerIdList.add(customerList.get(i).getCustomerId());
			customerNameList.add(customerList.get(i).getCustomerFirstName());
			
		}
		
		for(int i=0;i<userList.size();i++){
			
			userIdList.add(userList.get(i).getUserId());
			userNameList.add(userList.get(i).getUserFirstName());
			
		}
	
		model.addObject("productNames", productNameList);
		model.addObject("productSupp", supplierNameList);
		model.addObject("productStock", stockList);
		model.addObject("productPrice", unitPriceList);
		
		model.addObject("customerList", customerIdList);
		model.addObject("customerNames", customerNameList);
		
		model.addObject("userList", userIdList);
		model.addObject("userNames", userNameList);
		
		return model;
	}
	
	@RequestMapping(value="/addOrd",method = RequestMethod.POST)
	public ModelAndView Addition(@ModelAttribute("order") @Valid Order order,BindingResult result) {

		logger.info("The order is being processed");
		
		boolean addedStatus = orderService.addOrder(order);
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach); 
    	viewModel.addObject("reattachModel","vieworder"); 
    	List<Order> orderList = orderService.getOrders();
    	viewModel.addObject("orderinfo",orderList);    
    	
				
		if(addedStatus){
			viewModel.addObject("message", "Order Successfully Placed");
			logger.info("The Order was placed Successfully");
		}
		else
		{
			viewModel.addObject("message", "Sorry! Order cannot be placed");
			logger.warn("The order could not be placed ");
		}
		return viewModel;
	}
		
	@RequestMapping(value = "/viewOrder", method = RequestMethod.GET)
	public ModelAndView getCustomers(){
		
		logger.info("Order data is being viewed");
		
		List<Order> orderList = orderService.getOrders();
		
		String attach = "vieworder";
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);   
    	model.addObject("orderinfo",orderList);    	
    	return model;
    	
	}
	
	@RequestMapping(value = "/editOrderDetails", method = RequestMethod.POST)
	public ModelAndView editCustomerDetails(Order order,BindingResult result,@RequestParam("ordId") String orderId ){
		
		logger.info("Data of an order with Id "+orderId+" to be edited");
		
		List<Order> orderList = orderService.getOrderDetailsToEdit(orderId);
		
		String attach = "orderInfoToEdit" ;
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);   
    	model.addObject("orderinfo",orderList);    
    	
    	List<ProductModel> productList = productService.getProductsList();
		List<CustomerModel> customerList = customerService.getCustomers();
		List<UserModel> userList = userService.getUsers();
		
		List<String> productNameList = new ArrayList<String>();
		List<String> supplierNameList = new ArrayList<String>();
		List<Integer> stockList = new ArrayList<Integer>();
		List<Float> unitPriceList = new ArrayList<Float>();
		
		List<String> customerIdList = new ArrayList<String>();
		//List<String> customerNameList = new ArrayList<String>();
		
		List<String> userIdList = new ArrayList<String>();
		//List<String> userNameList = new ArrayList<String>();
		
		for(int i=0;i<productList.size();i++){
			
			productNameList.add(productList.get(i).getProductName());
			supplierNameList.add(productList.get(i).getSupplierName());
			stockList.add(productList.get(i).getStock());
			unitPriceList.add(productList.get(i).getUnitPrice());
			
		}
		
		for(int i=0;i<customerList.size();i++){
			
			customerIdList.add(customerList.get(i).getCustomerId());
			//customerNameList.add(customerList.get(i).getCustomerFirstName());
			
		}
		
		for(int i=0;i<userList.size();i++){
			
			userIdList.add(userList.get(i).getUserId());
			//userNameList.add(userList.get(i).getUserFirstName());
			
		}
	
		model.addObject("productNames", productNameList);
		model.addObject("productSupp", supplierNameList);
		model.addObject("productStock", stockList);
		model.addObject("productPrice", unitPriceList);
		
		model.addObject("customerList", customerIdList);
		//model.addObject("customerNames", customerNameList);
		
		model.addObject("userList", userIdList);
		//model.addObject("userNames", userNameList);	
    	
    	return model;
	}
	
	@RequestMapping(value = "/deleteOrd", method = RequestMethod.POST)
	public ModelAndView delete(@RequestParam("ordId") String orderId ){
		
		logger.info("The order with Id: "+orderId+" is being deleted from the database");
				
		boolean isdeleted = false;
		
		try{
			isdeleted = orderService.deleteOrder(orderId);
		}
		catch (NullPointerException e) {
			// TODO: handle exception
			logger.error("An error has occurred while deleting order data from datbase");
		}
		
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach); 
    	viewModel.addObject("reattachModel","vieworder"); 
    	List<Order> orderList = orderService.getOrders();
    	viewModel.addObject("orderinfo",orderList);  
				
		if(isdeleted){
			viewModel.addObject("message", "Order Deleted Successfully");
			logger.info("Order deleted successfully from database");
		}
		else
		{
			viewModel.addObject("message", "Sorry! Order cannot be deleted");
			logger.warn("Order could not be deleted");
		}
		return viewModel;
	}
	
	@RequestMapping(value="/editOrd",method = RequestMethod.POST)
	public ModelAndView edition(@ModelAttribute("order") @Valid Order order,BindingResult result,@RequestParam("editquantity") int editQuant) {

		boolean addedStatus = orderService.editOrder(order,editQuant);
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach); 
    	viewModel.addObject("reattachModel","vieworder"); 
    	List<Order> orderList = orderService.getOrders();
    	viewModel.addObject("orderinfo",orderList);  
				
		if(addedStatus){
			viewModel.addObject("message", "Order Edited Successfully");
			logger.info("Order edited successfully in database");
		}
		else
		{
			viewModel.addObject("message", "Sorry! Order cannot be edited");
			logger.warn("Order could not be edited");
		}
		return viewModel;
	}
		
}
