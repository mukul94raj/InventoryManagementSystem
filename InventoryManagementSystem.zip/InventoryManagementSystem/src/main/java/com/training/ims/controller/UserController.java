package com.training.ims.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.training.ims.model.UserModel;
import com.training.ims.service.IUserService;

@Controller
public class UserController {	
	
	@Autowired
	private IUserService userService;
	
	static Logger logger = Logger.getLogger(LoginController.class);
	
	@RequestMapping(value="/addUser",method = RequestMethod.GET)
	public ModelAndView AddProcess(HttpServletRequest request,HttpServletResponse response,UserModel userModel){
    	
		logger.info("A Form is displayed to add an user");
		
		List<UserModel> userList = userService.getUsers();
		List<String> userIdList = new ArrayList<String>();
		for(int i = 0; i<userList.size();i++){
			userIdList.add(userList.get(i).getUserId());
		}
		
		String attach = "adduser" ;
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("ListOfIds",userIdList);
    	model.addObject("attachModel",attach);    	
    	return model;
    }	
	
	@RequestMapping(value="/addinguser",method = RequestMethod.POST)
	public ModelAndView Addition(@ModelAttribute("userModel") @Valid UserModel userModel,BindingResult result) {
		
		logger.info("An add user form was filled and submitted");
		logger.warn("The data from add user form is being sent to the database");
	
		boolean addedStatus = userService.addUserInfo(userModel);
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach);   
    	List<UserModel> userList = userService.getUsers();
    	viewModel.addObject("reattachModel","viewuser");
    	viewModel.addObject("userinfo",userList);  
				
		if(addedStatus){
			logger.info("User data successfully added");
			viewModel.addObject("message", "User Data Successfully Added");
		}
		else{
			logger.warn("User data cannot be added");
			viewModel.addObject("message", "Sorry! User data cannot be added");
		}
		return viewModel;
	}
	
	@RequestMapping(value = "/deleteUserinfo", method = RequestMethod.POST)
	public ModelAndView delete(@RequestParam("userId") String userId ){
		
		boolean isdeleted = userService.deletingUser(userId);
		
		String attach = "Message" ;
    	ModelAndView viewModel=new ModelAndView("successview");
    	viewModel.addObject("attachModel",attach);   
    	List<UserModel> userList = userService.getUsers();
    	viewModel.addObject("reattachModel","viewuser");
    	viewModel.addObject("userinfo",userList);  
		
		if(isdeleted){
			logger.info("User data successfully deleted");
			viewModel.addObject("message","User Data deleted successfully");    			
		}
		else{
			logger.warn("User data cannot be deleted");
			viewModel.addObject("message", "Sorry!User Data cannot be deleted");  
		}
		
		return viewModel;
	}
	
	
	@RequestMapping(value = "/viewUser", method = RequestMethod.GET)
	public ModelAndView getUsers(){
		
		logger.info("User data being viewed");
		
		List<UserModel> userList = userService.getUsers();
		
		String attach = "viewuser";
    	ModelAndView model=new ModelAndView("successview");
    	model.addObject("attachModel",attach);   
    	model.addObject("userinfo",userList);    	
    	return model;
    	
	}
	
	@RequestMapping(value = "/editUserDetails", method = RequestMethod.POST)
	 public ModelAndView editingDetails(UserModel userModel,BindingResult result,@RequestParam("userId") String userId ){
	  
		logger.info("Data of a user with id "+userId  +" to be edited");
		
	  List<UserModel> userList = userService.getUserDetailsToEdit(userId);
	  
	  String attach = "userInfoToEdit" ;
	     ModelAndView model=new ModelAndView("successview");
	     model.addObject("attachModel",attach);   
	     model.addObject("userinfo",userList);     
	     return model;
	 }
	 
	 @RequestMapping(value = "/editUser", method = RequestMethod.POST)
	 public ModelAndView edit(@ModelAttribute("userModel") @Valid UserModel userModel,BindingResult result){
	  
	  boolean isdeleted = false;
	  
	  try{
	   isdeleted = userService.editUser(userModel);
	  }
	  catch (NullPointerException e) {
	   // TODO: handle exception
	   logger.error("An error has occurred while editing user data from database");
	  }
	  
	    String attach = "Message" ;
	  	ModelAndView viewModel=new ModelAndView("successview");
	  	viewModel.addObject("attachModel",attach);   
	  	List<UserModel> userList = userService.getUsers();
	  	viewModel.addObject("reattachModel","viewuser"); 
	  	viewModel.addObject("userinfo",userList);  
	  
	  if(isdeleted){
		  viewModel.addObject("message","User data edited successfully");   
		  logger.info("User data edited successfully");
	  }
	  else{
		  viewModel.addObject("message", "Sorry!User data cannot be edited");  
		  logger.info("User data cannot be edited");
	  }  
	  return viewModel;
	 }
}




