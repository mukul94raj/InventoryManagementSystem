package com.training.ims.dao;

import java.util.List;
import javax.sql.DataSource;
import com.training.ims.model.Order;

public interface IOrderDao {
	public abstract void setDataSource(DataSource dataSource);
	public abstract boolean addOrder(Order order);
	public abstract List<Order> getOrders();
	public abstract List<Order> getOrderDetailsToEdit(String orderId);
	public abstract boolean editOrder(Order order,int editQuant);
	public abstract boolean deleteOrder(String orderId);
}
